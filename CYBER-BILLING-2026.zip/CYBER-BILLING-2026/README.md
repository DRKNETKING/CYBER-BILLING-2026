# CYBER BILLING 2026 — Warnet Control Center

Dashboard demo billing warnet berbasis HTML, CSS, dan JavaScript.

## Fitur
- Dashboard ringkasan komputer, sesi aktif, ketersediaan, dan pendapatan hari ini.
- 20 komputer contoh, tambah workstation, cari dan filter status.
- Mulai, jeda, lanjutkan, dan akhiri sesi; biaya dihitung berdasarkan tarif per jam.
- Riwayat transaksi dan laporan pendapatan.
- Ekspor transaksi ke CSV.
- Pengaturan nama usaha dan tarif.
- Penyimpanan lokal melalui `localStorage` browser.
- Tampilan responsif untuk desktop dan ponsel.

## Menjalankan
1. Buka `index.html` langsung di browser, atau unggah file ini ke repository GitHub.
2. Untuk mempublikasikan dengan GitHub Pages: buka **Settings → Pages**, pilih branch `main` dan folder `/ (root)`, lalu simpan.
3. Tunggu sampai GitHub Pages memberikan URL situs.

## Batasan penting
Ini adalah **demo lokal**, bukan pengganti penuh software billing Cyberindo/Cyberindo Billing. Data tersimpan hanya di browser yang digunakan. Tidak ada backend/database bersama, autentikasi admin, kontrol jaringan, penguncian PC klien, atau agent di komputer pelanggan. Untuk operasional warnet sungguhan, dibutuhkan backend/server lokal dan aplikasi klien yang terpasang di tiap PC. Jangan masukkan data sensitif ke demo ini.
